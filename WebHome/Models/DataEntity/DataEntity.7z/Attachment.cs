﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class Attachment
    {
        public Attachment()
        {
            Article = new HashSet<Article>();
            CourseContractExtension = new HashSet<CourseContractExtension>();
            CourseContractRevision = new HashSet<CourseContractRevision>();
            UserProfile = new HashSet<UserProfile>();
        }

        public int AttachmentID { get; set; }
        public string StoredPath { get; set; }
        public int? DocID { get; set; }

        public virtual Document Doc { get; set; }
        public virtual ICollection<Article> Article { get; set; }
        public virtual ICollection<CourseContractExtension> CourseContractExtension { get; set; }
        public virtual ICollection<CourseContractRevision> CourseContractRevision { get; set; }
        public virtual ICollection<UserProfile> UserProfile { get; set; }
    }
}
