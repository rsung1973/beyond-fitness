﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class ProfessionalLevelReview
    {
        public int LevelID { get; set; }
        public int? PromotionID { get; set; }
        public int? DemotionID { get; set; }
        public int CheckLevel { get; set; }
        public int? NormalAttendanceCount { get; set; }
        public int? NormalAchievement { get; set; }
        public int? PromotionAttendanceCount { get; set; }
        public int? PromotionAchievement { get; set; }

        public virtual ProfessionalLevel DemotionLevel { get; set; }
        public virtual ProfessionalLevel ProfessionalLevel { get; set; }
        public virtual ProfessionalLevel PromotionLevel { get; set; }
    }
}
