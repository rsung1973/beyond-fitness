﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class BodyDiagnosis
    {
        public BodyDiagnosis()
        {
            BodySuffering = new HashSet<BodySuffering>();
            DiagnosisAssessment = new HashSet<DiagnosisAssessment>();
        }

        public int DiagnosisID { get; set; }
        public DateTime DiagnosisDate { get; set; }
        public int LearnerID { get; set; }
        public int CoachID { get; set; }
        public int LevelID { get; set; }
        public string Goal { get; set; }
        public string Description { get; set; }

        public virtual UserProfile Coach { get; set; }
        public virtual UserProfile Learner { get; set; }
        public virtual LevelExpression Level { get; set; }
        public virtual ICollection<BodySuffering> BodySuffering { get; set; }
        public virtual ICollection<DiagnosisAssessment> DiagnosisAssessment { get; set; }
    }
}
