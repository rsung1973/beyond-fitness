﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class ObjectiveContractLessonPrice
    {
        public int ContractType { get; set; }
        public int PriceID { get; set; }

        public virtual CourseContractType ContractTypeNavigation { get; set; }
        public virtual LessonPriceType Price { get; set; }
    }
}
