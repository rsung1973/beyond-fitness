﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class TuitionAchievement
    {
        public int InstallmentID { get; set; }
        public int CoachID { get; set; }
        public int? ShareAmount { get; set; }
        public DateTime? CommitShare { get; set; }
        public int? CoachWorkPlace { get; set; }

        public virtual ServingCoach ServingCoach { get; set; }
        public virtual BranchStore BranchStore { get; set; }
        public virtual Payment Payment { get; set; }
    }
}
