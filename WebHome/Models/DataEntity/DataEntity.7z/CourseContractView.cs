﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class CourseContractView
    {
        public int TypeID { get; set; }
        public int BranchID { get; set; }
        public string ViewPath { get; set; }

        public virtual BranchStore Branch { get; set; }
        public virtual CourseContractType Type { get; set; }
    }
}
