﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class V_WorkPlace
    {
        public int CoachID { get; set; }
        public int? WorkPlace { get; set; }
        public string OfficeLocation { get; set; }
    }
}
