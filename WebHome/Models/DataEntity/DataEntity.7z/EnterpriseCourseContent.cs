﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class EnterpriseCourseContent
    {
        public EnterpriseCourseContent()
        {
            RegisterLessonEnterprise = new HashSet<RegisterLessonEnterprise>();
        }

        public int ContractID { get; set; }
        public int TypeID { get; set; }
        public int? Lessons { get; set; }
        public int? ListPrice { get; set; }
        public int? DurationInMinutes { get; set; }
        public int? CoachPayoff { get; set; }

        public virtual EnterpriseCourseContract EnterpriseCourseContract { get; set; }
        public virtual EnterpriseLessonType EnterpriseLessonType { get; set; }
        public virtual ICollection<RegisterLessonEnterprise> RegisterLessonEnterprise { get; set; }
    }
}
