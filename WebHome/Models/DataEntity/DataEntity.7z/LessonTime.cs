﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class LessonTime
    {
        public LessonTime()
        {
            ContractTrustTrack = new HashSet<ContractTrustTrack>();
            LessonFeedBack = new HashSet<LessonFeedBack>();
            LessonFitnessAssessment = new HashSet<LessonFitnessAssessment>();
            LessonTimeExpansion = new HashSet<LessonTimeExpansion>();
            TrainingPlan = new HashSet<TrainingPlan>();
        }

        public int LessonID { get; set; }
        public int RegisterID { get; set; }
        public DateTime? ClassTime { get; set; }
        public int? DurationInMinutes { get; set; }
        public int? InvitedCoach { get; set; }
        public int? AttendingCoach { get; set; }
        public int? GroupID { get; set; }
        public int? TrainingBySelf { get; set; }
        public int? BranchID { get; set; }
        public int? HourOfClassTime { get; set; }
        public string Place { get; set; }

        public virtual ServingCoach AsAttendingCoach { get; set; }
        public virtual BranchStore BranchStore { get; set; }
        public virtual GroupingLesson GroupingLesson { get; set; }
        public virtual DailyWorkingHour DailyWorkingHour { get; set; }
        public virtual ServingCoach AsInvitedCoach { get; set; }
        public virtual RegisterLesson RegisterLesson { get; set; }
        public virtual FitnessAssessment FitnessAssessment { get; set; }
        public virtual LessonAttendance LessonAttendance { get; set; }
        public virtual LessonPlan LessonPlan { get; set; }
        public virtual LessonTimeSettlement LessonTimeSettlement { get; set; }
        public virtual LessonTrend LessonTrend { get; set; }
        public virtual PreferredLessonTime PreferredLessonTime { get; set; }
        public virtual ICollection<ContractTrustTrack> ContractTrustTrack { get; set; }
        public virtual ICollection<LessonFeedBack> LessonFeedBack { get; set; }
        public virtual ICollection<LessonFitnessAssessment> LessonFitnessAssessment { get; set; }
        public virtual ICollection<LessonTimeExpansion> LessonTimeExpansion { get; set; }
        public virtual ICollection<TrainingPlan> TrainingPlan { get; set; }
    }
}
