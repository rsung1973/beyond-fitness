﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class UserRelationship
    {
        public int LeaderID { get; set; }
        public int UID { get; set; }
        public string Memo { get; set; }

        public virtual UserProfile Leader { get; set; }
        public virtual UserProfile UIDNavigation { get; set; }
    }
}
