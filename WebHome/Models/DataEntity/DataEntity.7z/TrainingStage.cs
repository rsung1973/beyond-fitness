﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class TrainingStage
    {
        public TrainingStage()
        {
            TrainingAids = new HashSet<TrainingAids>();
            TrainingExecutionStage = new HashSet<TrainingExecutionStage>();
            TrainingStageItem = new HashSet<TrainingStageItem>();
        }

        public int StageID { get; set; }
        public string Stage { get; set; }

        public virtual ICollection<TrainingAids> TrainingAids { get; set; }
        public virtual ICollection<TrainingExecutionStage> TrainingExecutionStage { get; set; }
        public virtual ICollection<TrainingStageItem> TrainingStageItem { get; set; }
    }
}
