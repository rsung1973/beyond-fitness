﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class LessonAttendanceDueDate
    {
        public DateTime DueDate { get; set; }
    }
}
