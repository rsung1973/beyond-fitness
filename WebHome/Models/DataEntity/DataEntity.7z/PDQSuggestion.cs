﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class PDQSuggestion
    {
        public PDQSuggestion()
        {
            PDQTask = new HashSet<PDQTask>();
            PDQTaskItem = new HashSet<PDQTaskItem>();
        }

        public int SuggestionID { get; set; }
        public int QuestionID { get; set; }
        public string Suggestion { get; set; }
        public bool? RightAnswer { get; set; }

        public virtual PDQQuestion Question { get; set; }
        public virtual ICollection<PDQTask> PDQTask { get; set; }
        public virtual ICollection<PDQTaskItem> PDQTaskItem { get; set; }
    }
}
