﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class ExerciseGameItem
    {
        public ExerciseGameItem()
        {
            ExerciseGameRank = new HashSet<ExerciseGameRank>();
            ExerciseGameResult = new HashSet<ExerciseGameResult>();
        }

        public int ExerciseID { get; set; }
        public string Exercise { get; set; }
        public string Unit { get; set; }
        public bool? Descending { get; set; }

        public virtual ICollection<ExerciseGameRank> ExerciseGameRank { get; set; }
        public virtual ICollection<ExerciseGameResult> ExerciseGameResult { get; set; }
    }
}
