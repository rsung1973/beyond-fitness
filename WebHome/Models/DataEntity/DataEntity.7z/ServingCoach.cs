﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class ServingCoach
    {
        public ServingCoach()
        {
            CoachCertificate = new HashSet<CoachCertificate>();
            CoachMonthlySalary = new HashSet<CoachMonthlySalary>();
            CoachRating = new HashSet<CoachRating>();
            CoachWorkplace = new HashSet<CoachWorkplace>();
            ContractElement = new HashSet<ContractElement>();
            CourseContract = new HashSet<CourseContract>();
            CourseContractRevisionItem = new HashSet<CourseContractRevisionItem>();
            LearnerFitnessAdvisor = new HashSet<LearnerFitnessAdvisor>();
            LessonTimeAttendingCoachNavigation = new HashSet<LessonTime>();
            LessonTimeInvitedCoachNavigation = new HashSet<LessonTime>();
            MonthlyCoachRevenueIndicator = new HashSet<MonthlyCoachRevenueIndicator>();
            RegisterLesson = new HashSet<RegisterLesson>();
            TuitionAchievement = new HashSet<TuitionAchievement>();
        }

        public int CoachID { get; set; }
        public string Description { get; set; }
        public int? LevelID { get; set; }
        public DateTime? EmploymentDate { get; set; }

        public virtual UserProfile UserProfile { get; set; }
        public virtual ProfessionalLevel ProfessionalLevel { get; set; }
        public virtual ICollection<CoachCertificate> CoachCertificate { get; set; }
        public virtual ICollection<CoachMonthlySalary> CoachMonthlySalary { get; set; }
        public virtual ICollection<CoachRating> CoachRating { get; set; }
        public virtual ICollection<CoachWorkplace> CoachWorkplace { get; set; }
        public virtual ICollection<ContractElement> ContractElement { get; set; }
        public virtual ICollection<CourseContract> CourseContract { get; set; }
        public virtual ICollection<CourseContractRevisionItem> CourseContractRevisionItem { get; set; }
        public virtual ICollection<LearnerFitnessAdvisor> LearnerFitnessAdvisor { get; set; }
        public virtual ICollection<LessonTime> LessonTimeAttendingCoachNavigation { get; set; }
        public virtual ICollection<LessonTime> LessonTimeInvitedCoachNavigation { get; set; }
        public virtual ICollection<MonthlyCoachRevenueIndicator> MonthlyCoachRevenueIndicator { get; set; }
        public virtual ICollection<RegisterLesson> RegisterLesson { get; set; }
        public virtual ICollection<TuitionAchievement> TuitionAchievement { get; set; }
    }
}
