﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class InvoiceTrackCodeAssignment
    {
        public InvoiceTrackCodeAssignment()
        {
            InvoiceNoInterval = new HashSet<InvoiceNoInterval>();
        }

        public int TrackID { get; set; }
        public int SellerID { get; set; }

        public virtual Organization Organization { get; set; }
        public virtual InvoiceTrackCode InvoiceTrackCode { get; set; }
        public virtual ICollection<InvoiceNoInterval> InvoiceNoInterval { get; set; }
    }
}
