﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class TrainingItemAids
    {
        public int ItemID { get; set; }
        public int AidID { get; set; }

        public virtual TrainingAids TrainingAids { get; set; }
        public virtual TrainingItem TrainingItem { get; set; }
    }
}
