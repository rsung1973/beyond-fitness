﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class PDQTask
    {
        public PDQTask()
        {
            PDQTaskItem = new HashSet<PDQTaskItem>();
        }

        public int TaskID { get; set; }
        public int UID { get; set; }
        public int? SuggestionID { get; set; }
        public int? QuestionID { get; set; }
        public string PDQAnswer { get; set; }
        public bool? YesOrNo { get; set; }
        public DateTime? TaskDate { get; set; }
        public int? QuestionnaireID { get; set; }

        public virtual PDQQuestion PDQQuestion { get; set; }
        public virtual QuestionnaireRequest QuestionnaireRequest { get; set; }
        public virtual PDQSuggestion PDQSuggestion { get; set; }
        public virtual UserProfile UserProfile { get; set; }
        public virtual PDQTaskBonus PDQTaskBonus { get; set; }
        public virtual ICollection<PDQTaskItem> PDQTaskItem { get; set; }
    }
}
