﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class LessonPricePackage
    {
        public int PriceID { get; set; }
        public int ItemID { get; set; }
        public int? Lessons { get; set; }

        public virtual LessonPriceType Item { get; set; }
        public virtual LessonPriceType PackageItemPrice { get; set; }
    }
}
