﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class DailyWorkingHour
    {
        public DailyWorkingHour()
        {
            LessonTime = new HashSet<LessonTime>();
        }

        public int Hour { get; set; }

        public virtual ICollection<LessonTime> LessonTime { get; set; }
    }
}
