﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class EnterpriseCourseMember
    {
        public int ContractID { get; set; }
        public int UID { get; set; }
        public int? GroupID { get; set; }

        public virtual EnterpriseCourseContract EnterpriseCourseContract { get; set; }
        public virtual GroupingLesson GroupingLesson { get; set; }
        public virtual UserProfile UserProfile { get; set; }
    }
}
