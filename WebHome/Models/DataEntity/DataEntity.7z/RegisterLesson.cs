﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class RegisterLesson
    {
        public RegisterLesson()
        {
            AwardingLesson = new HashSet<AwardingLesson>();
            AwardingLessonGift = new HashSet<AwardingLessonGift>();
            LessonFeedBack = new HashSet<LessonFeedBack>();
            LessonTime = new HashSet<LessonTime>();
            LessonTimeExpansion = new HashSet<LessonTimeExpansion>();
            QuestionnaireRequest = new HashSet<QuestionnaireRequest>();
            TrainingPlan = new HashSet<TrainingPlan>();
        }

        public int RegisterID { get; set; }
        public DateTime RegisterDate { get; set; }
        public int Lessons { get; set; }
        public int UID { get; set; }
        public int? ClassLevel { get; set; }
        public int? Attended { get; set; }
        public int? RegisterGroupID { get; set; }
        public int GroupingMemberCount { get; set; }
        public int? AdvisorID { get; set; }
        public int? AttendedLessons { get; set; }
        public int? BranchID { get; set; }
        public bool? MasterRegistration { get; set; }

        public virtual ServingCoach ServingCoach { get; set; }
        public virtual LevelExpression LevelExpression { get; set; }
        public virtual BranchStore BranchStore { get; set; }
        public virtual LessonPriceType LessonPriceType { get; set; }
        public virtual GroupingLessonDiscount GroupingLessonDiscount { get; set; }
        public virtual GroupingLesson GroupingLesson { get; set; }
        public virtual UserProfile UserProfile { get; set; }
        public virtual IntuitionCharge IntuitionCharge { get; set; }
        public virtual RegisterLessonContract RegisterLessonContract { get; set; }
        public virtual RegisterLessonEnterprise RegisterLessonEnterprise { get; set; }
        public virtual ICollection<AwardingLesson> AwardingLesson { get; set; }
        public virtual ICollection<AwardingLessonGift> AwardingLessonGift { get; set; }
        public virtual ICollection<LessonFeedBack> LessonFeedBack { get; set; }
        public virtual ICollection<LessonTime> LessonTime { get; set; }
        public virtual ICollection<LessonTimeExpansion> LessonTimeExpansion { get; set; }
        public virtual ICollection<QuestionnaireRequest> QuestionnaireRequest { get; set; }
        public virtual ICollection<TrainingPlan> TrainingPlan { get; set; }
    }
}
