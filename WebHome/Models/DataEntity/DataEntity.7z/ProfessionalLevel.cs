﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class ProfessionalLevel
    {
        public ProfessionalLevel()
        {
            CoachMonthlySalary = new HashSet<CoachMonthlySalary>();
            CoachRating = new HashSet<CoachRating>();
            LessonTimeSettlement = new HashSet<LessonTimeSettlement>();
            MonthlyCoachRevenueIndicator = new HashSet<MonthlyCoachRevenueIndicator>();
            DemotingFrom = new HashSet<ProfessionalLevelReview>();
            PromotingFrom = new HashSet<ProfessionalLevelReview>();
            ServingCoach = new HashSet<ServingCoach>();
        }

        public int LevelID { get; set; }
        public string LevelName { get; set; }
        public decimal? GradeIndex { get; set; }
        public int? CategoryID { get; set; }
        public string DisplayName { get; set; }

        public virtual LevelExpression Category { get; set; }
        public virtual ProfessionalLevelReview ProfessionalLevelReview { get; set; }
        public virtual ICollection<CoachMonthlySalary> CoachMonthlySalary { get; set; }
        public virtual ICollection<CoachRating> CoachRating { get; set; }
        public virtual ICollection<LessonTimeSettlement> LessonTimeSettlement { get; set; }
        public virtual ICollection<MonthlyCoachRevenueIndicator> MonthlyCoachRevenueIndicator { get; set; }
        public virtual ICollection<ProfessionalLevelReview> DemotingFrom { get; set; }
        public virtual ICollection<ProfessionalLevelReview> PromotingFrom { get; set; }
        public virtual ICollection<ServingCoach> ServingCoach { get; set; }
    }
}
