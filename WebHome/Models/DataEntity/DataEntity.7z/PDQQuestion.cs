﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class PDQQuestion
    {
        public PDQQuestion()
        {
            PDQGroupAsConcludion = new HashSet<PDQGroup>();
            PDQSuggestion = new HashSet<PDQSuggestion>();
            PDQTask = new HashSet<PDQTask>();
        }

        public int QuestionID { get; set; }
        public string Question { get; set; }
        public int? QuestionType { get; set; }
        public bool? RightAnswer { get; set; }
        public int? QuestionNo { get; set; }
        public int? GroupID { get; set; }
        public int? AskerID { get; set; }

        public virtual UserProfile UserProfile { get; set; }
        public virtual PDQGroup PDQGroup { get; set; }
        public virtual LevelExpression LevelExpression { get; set; }
        public virtual PDQQuestionExtension PDQQuestionExtension { get; set; }
        public virtual PDQType PDQType { get; set; }
        public virtual ICollection<PDQGroup> PDQGroupAsConcludion { get; set; }
        public virtual ICollection<PDQSuggestion> PDQSuggestion { get; set; }
        public virtual ICollection<PDQTask> PDQTask { get; set; }
    }
}
