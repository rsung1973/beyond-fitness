﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class TrainingStageItem
    {
        public int TrainingID { get; set; }
        public int StageID { get; set; }

        public virtual TrainingStage TrainingStage { get; set; }
        public virtual TrainingType TrainingType { get; set; }
    }
}
