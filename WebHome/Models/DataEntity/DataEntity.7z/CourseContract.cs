﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class CourseContract
    {
        public CourseContract()
        {
            ContractElement = new HashSet<ContractElement>();
            ContractMonthlySummary = new HashSet<ContractMonthlySummary>();
            ContractPayment = new HashSet<ContractPayment>();
            ContractTrustSettlement = new HashSet<ContractTrustSettlement>();
            ContractTrustTrack = new HashSet<ContractTrustTrack>();
            CourseContractLevel = new HashSet<CourseContractLevel>();
            CourseContractMember = new HashSet<CourseContractMember>();
            RevisionList = new HashSet<CourseContractRevision>();
            RegisterLessonContract = new HashSet<RegisterLessonContract>();
        }

        public int ContractID { get; set; }
        public int ContractType { get; set; }
        public DateTime? ContractDate { get; set; }
        public string Subject { get; set; }
        public DateTime? ValidFrom { get; set; }
        public DateTime? Expiration { get; set; }
        public int OwnerID { get; set; }
        public int? SequenceNo { get; set; }
        public int? Lessons { get; set; }
        public int PriceID { get; set; }
        public string Remark { get; set; }
        public int FitnessConsultant { get; set; }
        public int Status { get; set; }
        public int AgentID { get; set; }
        public string ContractNo { get; set; }
        public int? TotalCost { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public bool? Installment { get; set; }
        public bool? Renewal { get; set; }
        public int? InstallmentID { get; set; }
        public DateTime? PayoffDue { get; set; }
        public DateTime? ValidTo { get; set; }
        public bool? Entrusted { get; set; }
        public int? SupervisorID { get; set; }

        public virtual UserProfile ContractAgent { get; set; }
        public virtual CourseContractType CourseContractType { get; set; }
        public virtual ServingCoach ServingCoach { get; set; }
        public virtual ContractInstallment ContractInstallment { get; set; }
        public virtual UserProfile ContractOwner { get; set; }
        public virtual LessonPriceType LessonPriceType { get; set; }
        public virtual LevelExpression LevelExpression { get; set; }
        public virtual UserProfile Supervisor { get; set; }
        public virtual CourseContractExtension CourseContractExtension { get; set; }
        public virtual CourseContractRevision CourseContractRevision { get; set; }
        public virtual CourseContractTrust CourseContractTrust { get; set; }
        public virtual ICollection<ContractElement> ContractElement { get; set; }
        public virtual ICollection<ContractMonthlySummary> ContractMonthlySummary { get; set; }
        public virtual ICollection<ContractPayment> ContractPayment { get; set; }
        public virtual ICollection<ContractTrustSettlement> ContractTrustSettlement { get; set; }
        public virtual ICollection<ContractTrustTrack> ContractTrustTrack { get; set; }
        public virtual ICollection<CourseContractLevel> CourseContractLevel { get; set; }
        public virtual ICollection<CourseContractMember> CourseContractMember { get; set; }
        public virtual ICollection<CourseContractRevision> RevisionList { get; set; }
        public virtual ICollection<RegisterLessonContract> RegisterLessonContract { get; set; }
    }
}
