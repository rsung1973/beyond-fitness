﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class CourseContractMember
    {
        public CourseContractMember()
        {
            CourseContractSignature = new HashSet<CourseContractSignature>();
        }

        public int ContractID { get; set; }
        public int UID { get; set; }

        public virtual CourseContract CourseContract { get; set; }
        public virtual UserProfile UserProfile { get; set; }
        public virtual ICollection<CourseContractSignature> CourseContractSignature { get; set; }
    }
}
