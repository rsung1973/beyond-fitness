﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class InvoiceProduct
    {
        public InvoiceProduct()
        {
            InvoiceDetails = new HashSet<InvoiceDetails>();
            InvoiceProductItem = new HashSet<InvoiceProductItem>();
        }

        public int ProductID { get; set; }
        public string Brief { get; set; }

        public virtual ICollection<InvoiceDetails> InvoiceDetails { get; set; }
        public virtual ICollection<InvoiceProductItem> InvoiceProductItem { get; set; }
    }
}
