﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class LessonPriceType
    {
        public LessonPriceType()
        {
            BonusAwardingLesson = new HashSet<BonusAwardingLesson>();
            CourseContract = new HashSet<CourseContract>();
            AsPackageItem = new HashSet<LessonPricePackage>();
            LessonPricePackage = new HashSet<LessonPricePackage>();
            LessonPriceProperty = new HashSet<LessonPriceProperty>();
            ObjectiveContractLessonPrice = new HashSet<ObjectiveContractLessonPrice>();
            ObjectiveLessonPrice = new HashSet<ObjectiveLessonPrice>();
            RegisterLesson = new HashSet<RegisterLesson>();
        }

        public int PriceID { get; set; }
        public string Description { get; set; }
        public int? ListPrice { get; set; }
        public int? Status { get; set; }
        public int? UsageType { get; set; }
        public int? CoachPayoff { get; set; }
        public int? CoachPayoffCreditCard { get; set; }
        public int? ExcludeQuestionnaire { get; set; }
        public int? LowerLimit { get; set; }
        public int? UpperBound { get; set; }
        public int? BranchID { get; set; }
        public int? DiscountedPrice { get; set; }
        public int? DurationInMinutes { get; set; }
        public int? SeriesID { get; set; }
        public int? BundleCount { get; set; }
        public int? EffectiveMonths { get; set; }

        public virtual BranchStore BranchStore { get; set; }
        public virtual LessonPriceSeries CurrentPriceSeries { get; set; }
        public virtual LevelExpression LevelExpression { get; set; }
        public virtual UsageType UsageTypeDescription { get; set; }
        public virtual IsInternalLesson IsInternalLesson { get; set; }
        public virtual IsWelfareGiftLesson IsWelfareGiftLesson { get; set; }
        public virtual LessonPriceSeries LessonPriceSeries { get; set; }
        public virtual ICollection<BonusAwardingLesson> BonusAwardingLesson { get; set; }
        public virtual ICollection<CourseContract> CourseContract { get; set; }
        public virtual ICollection<LessonPricePackage> AsPackageItem { get; set; }
        public virtual ICollection<LessonPricePackage> LessonPricePackage { get; set; }
        public virtual ICollection<LessonPriceProperty> LessonPriceProperty { get; set; }
        public virtual ICollection<ObjectiveContractLessonPrice> ObjectiveContractLessonPrice { get; set; }
        public virtual ICollection<ObjectiveLessonPrice> ObjectiveLessonPrice { get; set; }
        public virtual ICollection<RegisterLesson> RegisterLesson { get; set; }
    }
}
