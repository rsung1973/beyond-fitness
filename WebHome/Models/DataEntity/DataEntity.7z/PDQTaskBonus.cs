﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class PDQTaskBonus
    {
        public PDQTaskBonus()
        {
            BonusExchange = new HashSet<BonusExchange>();
        }

        public int TaskID { get; set; }
        public int? BonusPoint { get; set; }

        public virtual PDQTask PDQTask { get; set; }
        public virtual ICollection<BonusExchange> BonusExchange { get; set; }
    }
}
