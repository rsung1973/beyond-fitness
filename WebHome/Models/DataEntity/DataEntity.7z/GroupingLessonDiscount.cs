﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class GroupingLessonDiscount
    {
        public GroupingLessonDiscount()
        {
            CourseContractType = new HashSet<CourseContractType>();
            RegisterLesson = new HashSet<RegisterLesson>();
        }

        public int GroupingMemberCount { get; set; }
        public int? PercentageOfDiscount { get; set; }

        public virtual ICollection<CourseContractType> CourseContractType { get; set; }
        public virtual ICollection<RegisterLesson> RegisterLesson { get; set; }
    }
}
