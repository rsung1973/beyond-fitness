﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class CourseContractExtension
    {
        public int ContractID { get; set; }
        public int BranchID { get; set; }
        public int? RevisionTrackingID { get; set; }
        public int? SettlementPrice { get; set; }
        public string PaymentMethod { get; set; }
        public int? Version { get; set; }
        public int? AttachmentID { get; set; }
        public bool? SignOnline { get; set; }

        public virtual Attachment Attachment { get; set; }
        public virtual BranchStore BranchStore { get; set; }
        public virtual CourseContract CourseContract { get; set; }
        public virtual CourseContractRevision CourseContractRevision { get; set; }
    }
}
