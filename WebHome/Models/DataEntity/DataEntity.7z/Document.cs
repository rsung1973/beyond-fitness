﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class Document
    {
        public Document()
        {
            Attachment = new HashSet<Attachment>();
            DerivedDocumentSource = new HashSet<DerivedDocument>();
            DocumentPrintLog = new HashSet<DocumentPrintLog>();
        }

        public int DocID { get; set; }
        public int? DocType { get; set; }
        public DateTime DocDate { get; set; }
        public int? CurrentStep { get; set; }
        public int? ChannelID { get; set; }

        public virtual LevelExpression LevelExpression { get; set; }
        public virtual DocumentType DocumentType { get; set; }
        public virtual Article Article { get; set; }
        public virtual BlogArticle BlogArticle { get; set; }
        public virtual DerivedDocument DerivedDocumentDoc { get; set; }
        public virtual DocumentPrintQueue DocumentPrintQueue { get; set; }
        public virtual InvoiceAllowance InvoiceAllowance { get; set; }
        public virtual InvoiceAllowanceSeller InvoiceAllowanceSeller { get; set; }
        public virtual InvoiceItem InvoiceItem { get; set; }
        public virtual ICollection<Attachment> Attachment { get; set; }
        public virtual ICollection<DerivedDocument> DerivedDocumentSource { get; set; }
        public virtual ICollection<DocumentPrintLog> DocumentPrintLog { get; set; }
    }
}
