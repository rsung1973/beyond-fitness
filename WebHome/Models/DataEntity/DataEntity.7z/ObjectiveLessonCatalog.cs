﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class ObjectiveLessonCatalog
    {
        public ObjectiveLessonCatalog()
        {
            ObjectiveLessonLocation = new HashSet<ObjectiveLessonLocation>();
            ObjectiveLessonPrice = new HashSet<ObjectiveLessonPrice>();
        }

        public int CatalogID { get; set; }
        public string Description { get; set; }

        public virtual ICollection<ObjectiveLessonLocation> ObjectiveLessonLocation { get; set; }
        public virtual ICollection<ObjectiveLessonPrice> ObjectiveLessonPrice { get; set; }
    }
}
