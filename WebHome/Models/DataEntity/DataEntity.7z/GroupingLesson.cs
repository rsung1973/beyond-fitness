﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class GroupingLesson
    {
        public GroupingLesson()
        {
            EnterpriseCourseMember = new HashSet<EnterpriseCourseMember>();
            LessonTime = new HashSet<LessonTime>();
            RegisterLesson = new HashSet<RegisterLesson>();
        }

        public int GroupID { get; set; }

        public virtual ICollection<EnterpriseCourseMember> EnterpriseCourseMember { get; set; }
        public virtual ICollection<LessonTime> LessonTime { get; set; }
        public virtual ICollection<RegisterLesson> RegisterLesson { get; set; }
    }
}
