﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class MonthlyBranchRevenueGoal
    {
        public int PeriodID { get; set; }
        public int BranchID { get; set; }
        public int GradeID { get; set; }
        public int? ActualLessonAchievement { get; set; }
        public int? ActualSharedAchievement { get; set; }
        public int? ActualCompleteLessonCount { get; set; }
        public decimal? CustomIndicatorPercentage { get; set; }
        public int? CustomRevenueGoal { get; set; }
        public int? AchievementGoal { get; set; }
        public int? CompleteLessonsGoal { get; set; }
        public int? LessonTuitionGoal { get; set; }
        public int? NewContractCount { get; set; }
        public int? RenewContractCount { get; set; }
        public int? ActualCompleteTSCount { get; set; }
        public int? ActualCompletePICount { get; set; }
        public int? NewContractSubtotal { get; set; }
        public int? RenewContractSubtotal { get; set; }
        public int? InstallmentCount { get; set; }
        public int? InstallmentSubtotal { get; set; }
        public int? NewContractAchievement { get; set; }
        public int? RenewContractAchievement { get; set; }
        public int? InstallmentAchievement { get; set; }

        public virtual MonthlyBranchRevenueIndicator MonthlyBranchRevenueIndicator { get; set; }
    }
}
