﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class MerchandiseWindow
    {
        public MerchandiseWindow()
        {
            MerchandiseTransaction = new HashSet<MerchandiseTransaction>();
            PaymentOrder = new HashSet<PaymentOrder>();
        }

        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public int? UnitPrice { get; set; }
        public int? Status { get; set; }
        public string SampleUrl { get; set; }

        public virtual LevelExpression StatusNavigation { get; set; }
        public virtual ICollection<MerchandiseTransaction> MerchandiseTransaction { get; set; }
        public virtual ICollection<PaymentOrder> PaymentOrder { get; set; }
    }
}
