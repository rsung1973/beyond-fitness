﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class Settlement
    {
        public Settlement()
        {
            CoachMonthlySalary = new HashSet<CoachMonthlySalary>();
            ContractTrustSettlement = new HashSet<ContractTrustSettlement>();
            ContractTrustTrack = new HashSet<ContractTrustTrack>();
            LessonTimeSettlement = new HashSet<LessonTimeSettlement>();
        }

        public int SettlementID { get; set; }
        public DateTime SettlementDate { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndExclusiveDate { get; set; }

        public virtual ICollection<CoachMonthlySalary> CoachMonthlySalary { get; set; }
        public virtual ICollection<ContractTrustSettlement> ContractTrustSettlement { get; set; }
        public virtual ICollection<ContractTrustTrack> ContractTrustTrack { get; set; }
        public virtual ICollection<LessonTimeSettlement> LessonTimeSettlement { get; set; }
    }
}
