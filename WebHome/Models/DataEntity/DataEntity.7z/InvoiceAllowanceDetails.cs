﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class InvoiceAllowanceDetails
    {
        public int AllowanceID { get; set; }
        public int ItemID { get; set; }

        public virtual InvoiceAllowance InvoiceAllowance { get; set; }
        public virtual InvoiceAllowanceItem InvoiceAllowanceItem { get; set; }
    }
}
