﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class ObjectiveLessonPrice
    {
        public int CatalogID { get; set; }
        public int PriceID { get; set; }

        public virtual ObjectiveLessonCatalog Catalog { get; set; }
        public virtual LessonPriceType Price { get; set; }
    }
}
