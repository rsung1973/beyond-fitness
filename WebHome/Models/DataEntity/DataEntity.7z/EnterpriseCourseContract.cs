﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class EnterpriseCourseContract
    {
        public EnterpriseCourseContract()
        {
            EnterpriseCourseContent = new HashSet<EnterpriseCourseContent>();
            EnterpriseCourseMember = new HashSet<EnterpriseCourseMember>();
            EnterpriseCoursePayment = new HashSet<EnterpriseCoursePayment>();
            RegisterLessonEnterprise = new HashSet<RegisterLessonEnterprise>();
        }

        public int ContractID { get; set; }
        public int CompanyID { get; set; }
        public string Remark { get; set; }
        public string Subject { get; set; }
        public string ContractNo { get; set; }
        public int? TotalCost { get; set; }
        public int? BranchID { get; set; }
        public DateTime? ValidFrom { get; set; }
        public DateTime? Expiration { get; set; }
        public int GroupingMemberCount { get; set; }

        public virtual BranchStore BranchStore { get; set; }
        public virtual Organization Organization { get; set; }
        public virtual ICollection<EnterpriseCourseContent> EnterpriseCourseContent { get; set; }
        public virtual ICollection<EnterpriseCourseMember> EnterpriseCourseMember { get; set; }
        public virtual ICollection<EnterpriseCoursePayment> EnterpriseCoursePayment { get; set; }
        public virtual ICollection<RegisterLessonEnterprise> RegisterLessonEnterprise { get; set; }
    }
}
