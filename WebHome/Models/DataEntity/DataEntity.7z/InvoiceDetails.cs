﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class InvoiceDetails
    {
        public int InvoiceID { get; set; }
        public int ProductID { get; set; }

        public virtual InvoiceItem InvoiceItem { get; set; }
        public virtual InvoiceProduct InvoiceProduct { get; set; }
    }
}
