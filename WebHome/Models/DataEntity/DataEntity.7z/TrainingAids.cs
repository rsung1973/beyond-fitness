﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class TrainingAids
    {
        public TrainingAids()
        {
            TrainingItemAids = new HashSet<TrainingItemAids>();
        }

        public int AidID { get; set; }
        public string ItemName { get; set; }
        public int? StageID { get; set; }
        public int? Status { get; set; }

        public virtual TrainingStage Stage { get; set; }
        public virtual ICollection<TrainingItemAids> TrainingItemAids { get; set; }
    }
}
