﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class CourseContractRevision
    {
        public CourseContractRevision()
        {
            ContractElement = new HashSet<ContractElement>();
            CourseContractExtension = new HashSet<CourseContractExtension>();
        }

        public int RevisionID { get; set; }
        public int? OriginalContract { get; set; }
        public int RevisionNo { get; set; }
        public string Reason { get; set; }
        public int? OperationMode { get; set; }
        public int? AttachmentID { get; set; }
        public int? MonthExtension { get; set; }
        public int? BySelf { get; set; }
        public int? ProcessingFee { get; set; }
        public int? CauseForEnding { get; set; }

        public virtual Attachment Attachment { get; set; }
        public virtual CourseContract SourceContract { get; set; }
        public virtual CourseContract CourseContract { get; set; }
        public virtual CourseContractRevisionItem CourseContractRevisionItem { get; set; }
        public virtual ICollection<ContractElement> ContractElement { get; set; }
        public virtual ICollection<CourseContractExtension> CourseContractExtension { get; set; }
    }
}
