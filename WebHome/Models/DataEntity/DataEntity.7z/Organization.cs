﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class Organization
    {
        public Organization()
        {
            EnterpriseCourseContract = new HashSet<EnterpriseCourseContract>();
            InvoiceAllowanceBuyer = new HashSet<InvoiceAllowanceBuyer>();
            InvoiceAllowanceSeller = new HashSet<InvoiceAllowanceSeller>();
            InvoiceBuyer = new HashSet<InvoiceBuyer>();
            InvoiceItem = new HashSet<InvoiceItem>();
            InvoiceSeller = new HashSet<InvoiceSeller>();
            InvoiceTrackCodeAssignment = new HashSet<InvoiceTrackCodeAssignment>();
        }

        public string ContactName { get; set; }
        public string Fax { get; set; }
        public string LogoURL { get; set; }
        public string CompanyName { get; set; }
        public int CompanyID { get; set; }
        public string ReceiptNo { get; set; }
        public string Phone { get; set; }
        public string ContactFax { get; set; }
        public string ContactPhone { get; set; }
        public string ContactMobilePhone { get; set; }
        public string RegAddr { get; set; }
        public string UndertakerName { get; set; }
        public string Addr { get; set; }
        public string EnglishName { get; set; }
        public string EnglishAddr { get; set; }
        public string EnglishRegAddr { get; set; }
        public string ContactEmail { get; set; }
        public string UndertakerPhone { get; set; }
        public string UndertakerFax { get; set; }
        public string UndertakerMobilePhone { get; set; }
        public string InvoiceSignature { get; set; }
        public string UndertakerID { get; set; }
        public string ContactTitle { get; set; }
        public string TaxNo { get; set; }

        public virtual BranchStore BranchStore { get; set; }
        public virtual ICollection<EnterpriseCourseContract> EnterpriseCourseContract { get; set; }
        public virtual ICollection<InvoiceAllowanceBuyer> InvoiceAllowanceBuyer { get; set; }
        public virtual ICollection<InvoiceAllowanceSeller> InvoiceAllowanceSeller { get; set; }
        public virtual ICollection<InvoiceBuyer> InvoiceBuyer { get; set; }
        public virtual ICollection<InvoiceItem> InvoiceItem { get; set; }
        public virtual ICollection<InvoiceSeller> InvoiceSeller { get; set; }
        public virtual ICollection<InvoiceTrackCodeAssignment> InvoiceTrackCodeAssignment { get; set; }
    }
}
