﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class MonthlyRevenueGrade
    {
        public MonthlyRevenueGrade()
        {
            MonthlyBranchRevenueIndicator = new HashSet<MonthlyBranchRevenueIndicator>();
            MonthlyRevenueIndicator = new HashSet<MonthlyRevenueIndicator>();
        }

        public int GradeID { get; set; }
        public int IndicatorPercentage { get; set; }
        public string Description { get; set; }

        public virtual ICollection<MonthlyBranchRevenueIndicator> MonthlyBranchRevenueIndicator { get; set; }
        public virtual ICollection<MonthlyRevenueIndicator> MonthlyRevenueIndicator { get; set; }
    }
}
