﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class Article
    {
        public Article()
        {
            ArticleCategory = new HashSet<ArticleCategory>();
        }

        public int DocID { get; set; }
        public string Title { get; set; }
        public string ArticleContent { get; set; }
        public int? AuthorID { get; set; }
        public int? Illustration { get; set; }
        public string Subtitle { get; set; }

        public virtual UserProfile UserProfile { get; set; }
        public virtual Document Document { get; set; }
        public virtual Attachment Attachment { get; set; }
        public virtual Publication Publication { get; set; }
        public virtual ICollection<ArticleCategory> ArticleCategory { get; set; }
    }
}
