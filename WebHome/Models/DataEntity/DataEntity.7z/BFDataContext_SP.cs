
using System;
using System.Data;
using System.Linq;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace WebHome.Models.DataEntity
{
    public partial class BFDataContext : DbContext
    {
        private DbSet<InquireAllVacantNoResult> SP_InquireAllVacantNo { get; set; }
        private DbSet<InquireVacantNoResult> SP_InquireVacantNo { get; set; }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder)
        {            
            // No key            
            modelBuilder.Entity<InquireAllVacantNoResult>(entity => {
                entity.HasNoKey();
            });
            modelBuilder.Entity<InquireVacantNoResult>().HasNoKey();
            //Thanks Valecass!!!
        }

        public int DeleteRedundantTrack()
        {
                // Processing 
                string sqlQuery = "EXEC [dbo].[DeleteRedundantTrack]";
                //Execution
                return this.Database.ExecuteSqlRaw(sqlQuery);
            //Return
        }

        public IEnumerable<InquireAllVacantNoResult> InquireAllVacantNo(System.Nullable<int> year, System.Nullable<int> periodNo)
        {
            string sqlQuery = "EXEC [dbo].[InquireAllVacantNo] {0},{1}";
            return this.SP_InquireAllVacantNo.FromSqlRaw(sqlQuery, year, periodNo)
                .AsEnumerable();
        }

        public IEnumerable<InquireVacantNoResult> InquireVacantNo(System.Nullable<int> sellerID, System.Nullable<int> year, System.Nullable<int> periodNo)
        {
            string sqlQuery = "EXEC [dbo].[InquireVacantNo] {0},{1},{2}";
            return this.SP_InquireVacantNo.FromSqlRaw(sqlQuery, sellerID, year, periodNo)
                .AsEnumerable();
        }

        public int ProcessInvoiceNo(System.Nullable<int> sellerID, System.Nullable<int> year, System.Nullable<int> periodNo)
        {
            string sqlQuery = "EXEC [dbo].[ProcessInvoiceNo] {0},{1},{2}";
            return this.Database.ExecuteSqlRaw(sqlQuery, sellerID, year, periodNo);
        }

    }
    public class InquireAllVacantNoResult
    {
        public int InvoiceNo { get; set; }
        public int Year { get; set; }
        public int PeriodNo { get; set; }
        public string TrackCode { get; set; }
        public int StartNo { get; set; }
        public int EndNo { get; set; }
        public int TrackID { get; set; }
        public int SellerID { get; set; }
        public int? CheckNext { get; set; }
        public int? CheckPrev { get; set; }
    }

    public class InquireVacantNoResult
    {
        public int InvoiceNo { get; set; }
        public int Year { get; set; }
        public int PeriodNo { get; set; }
        public string TrackCode { get; set; }
        public int StartNo { get; set; }
        public int EndNo { get; set; }
        public int TrackID { get; set; }
        public int SellerID { get; set; }
        public int? CheckNext { get; set; }
        public int? CheckPrev { get; set; }
    }

}