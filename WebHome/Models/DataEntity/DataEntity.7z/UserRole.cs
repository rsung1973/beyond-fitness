﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class UserRole
    {
        public int UID { get; set; }
        public int RoleID { get; set; }

        public virtual UserRoleDefinition UserRoleDefinition { get; set; }
        public virtual UserProfile UserProfile { get; set; }
    }
}
