﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class CourseContractType
    {
        public CourseContractType()
        {
            CourseContract = new HashSet<CourseContract>();
            CourseContractView = new HashSet<CourseContractView>();
            ObjectiveContractLessonPrice = new HashSet<ObjectiveContractLessonPrice>();
        }

        public int TypeID { get; set; }
        public string TypeName { get; set; }
        public string ContractCode { get; set; }
        public bool? IsGroup { get; set; }
        public int? GroupingMemberCount { get; set; }

        public virtual GroupingLessonDiscount GroupingLessonDiscount { get; set; }
        public virtual ICollection<CourseContract> CourseContract { get; set; }
        public virtual ICollection<CourseContractView> CourseContractView { get; set; }
        public virtual ICollection<ObjectiveContractLessonPrice> ObjectiveContractLessonPrice { get; set; }
    }
}
