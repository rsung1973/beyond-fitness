﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class UserProfile
    {
        public UserProfile()
        {
            Article = new HashSet<Article>();
            BlogArticle = new HashSet<BlogArticle>();
            BodyDiagnosisCoach = new HashSet<BodyDiagnosis>();
            BodyDiagnosisLearner = new HashSet<BodyDiagnosis>();
            BranchStoreManager = new HashSet<BranchStore>();
            BranchStoreViceManager = new HashSet<BranchStore>();
            CourseContractAgent = new HashSet<CourseContract>();
            CourseContractLevel = new HashSet<CourseContractLevel>();
            CourseContractMember = new HashSet<CourseContractMember>();
            CourseContractOwner = new HashSet<CourseContract>();
            CourseContractSupervisor = new HashSet<CourseContract>();
            DocumentPrintLog = new HashSet<DocumentPrintLog>();
            DocumentPrintQueue = new HashSet<DocumentPrintQueue>();
            EnterpriseCourseMember = new HashSet<EnterpriseCourseMember>();
            FavoriteLesson = new HashSet<FavoriteLesson>();
            GroupEvent = new HashSet<GroupEvent>();
            InverseAuth = new HashSet<UserProfile>();
            InverseCreatorNavigation = new HashSet<UserProfile>();
            ExchangedAward = new HashSet<LearnerAward>();
            LearnerAward = new HashSet<LearnerAward>();
            LearnerFitnessAdvisor = new HashSet<LearnerFitnessAdvisor>();
            LearnerFitnessAssessment = new HashSet<LearnerFitnessAssessment>();
            LessonAttendance = new HashSet<LessonAttendance>();
            LessonCommentHearer = new HashSet<LessonComment>();
            LessonCommentSpeaker = new HashSet<LessonComment>();
            LessonFitnessAssessment = new HashSet<LessonFitnessAssessment>();
            PDQQuestion = new HashSet<PDQQuestion>();
            PDQTask = new HashSet<PDQTask>();
            Payment = new HashSet<Payment>();
            PaymentAudit = new HashSet<PaymentAudit>();
            PreferredLessonTime = new HashSet<PreferredLessonTime>();
            QuestionnaireCoachBypass = new HashSet<QuestionnaireCoachBypass>();
            QuestionnaireCoachFinish = new HashSet<QuestionnaireCoachFinish>();
            QuestionnaireRequestCreator = new HashSet<QuestionnaireRequest>();
            QuestionnaireRequestUIDNavigation = new HashSet<QuestionnaireRequest>();
            RegisterLesson = new HashSet<RegisterLesson>();
            ResetPassword = new HashSet<ResetPassword>();
            UserEvent = new HashSet<UserEvent>();
            UserRelationshipLeader = new HashSet<UserRelationship>();
            UserRelationshipUIDNavigation = new HashSet<UserRelationship>();
            UserRole = new HashSet<UserRole>();
            UserRoleAuthorization = new HashSet<UserRoleAuthorization>();
            UserSignature = new HashSet<UserSignature>();
            VoidPayment = new HashSet<VoidPayment>();
            VoidPaymentLevel = new HashSet<VoidPaymentLevel>();
        }

        public int UID { get; set; }
        public string UserName { get; set; }
        public string PID { get; set; }
        public string Password { get; set; }
        public string ExternalID { get; set; }
        public DateTime? Expiration { get; set; }
        public int? Creator { get; set; }
        public int? AuthID { get; set; }
        public int? LevelID { get; set; }
        public string ThemeName { get; set; }
        public string Password2 { get; set; }
        public string MemberCode { get; set; }
        public int? PictureID { get; set; }
        public string RealName { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
        public string RecentStatus { get; set; }
        public DateTime? Birthday { get; set; }
        public string Nickname { get; set; }
        public int? BirthdateIndex { get; set; }
        public DateTime? CreateTime { get; set; }

        public virtual UserProfile Auth { get; set; }
        public virtual UserProfile CreatorNavigation { get; set; }
        public virtual LevelExpression Level { get; set; }
        public virtual Attachment Picture { get; set; }
        public virtual EmployeeWelfare EmployeeWelfare { get; set; }
        public virtual ExerciseGameContestant ExerciseGameContestant { get; set; }
        public virtual PDQUserAssessment PDQUserAssessment { get; set; }
        public virtual PersonalExercisePurpose PersonalExercisePurpose { get; set; }
        public virtual ServingCoach ServingCoach { get; set; }
        public virtual UserProfileExtension UserProfileExtension { get; set; }
        public virtual ICollection<Article> Article { get; set; }
        public virtual ICollection<BlogArticle> BlogArticle { get; set; }
        public virtual ICollection<BodyDiagnosis> BodyDiagnosisCoach { get; set; }
        public virtual ICollection<BodyDiagnosis> BodyDiagnosisLearner { get; set; }
        public virtual ICollection<BranchStore> BranchStoreManager { get; set; }
        public virtual ICollection<BranchStore> BranchStoreViceManager { get; set; }
        public virtual ICollection<CourseContract> CourseContractAgent { get; set; }
        public virtual ICollection<CourseContractLevel> CourseContractLevel { get; set; }
        public virtual ICollection<CourseContractMember> CourseContractMember { get; set; }
        public virtual ICollection<CourseContract> CourseContractOwner { get; set; }
        public virtual ICollection<CourseContract> CourseContractSupervisor { get; set; }
        public virtual ICollection<DocumentPrintLog> DocumentPrintLog { get; set; }
        public virtual ICollection<DocumentPrintQueue> DocumentPrintQueue { get; set; }
        public virtual ICollection<EnterpriseCourseMember> EnterpriseCourseMember { get; set; }
        public virtual ICollection<FavoriteLesson> FavoriteLesson { get; set; }
        public virtual ICollection<GroupEvent> GroupEvent { get; set; }
        public virtual ICollection<UserProfile> InverseAuth { get; set; }
        public virtual ICollection<UserProfile> InverseCreatorNavigation { get; set; }
        public virtual ICollection<LearnerAward> ExchangedAward { get; set; }
        public virtual ICollection<LearnerAward> LearnerAward { get; set; }
        public virtual ICollection<LearnerFitnessAdvisor> LearnerFitnessAdvisor { get; set; }
        public virtual ICollection<LearnerFitnessAssessment> LearnerFitnessAssessment { get; set; }
        public virtual ICollection<LessonAttendance> LessonAttendance { get; set; }
        public virtual ICollection<LessonComment> LessonCommentHearer { get; set; }
        public virtual ICollection<LessonComment> LessonCommentSpeaker { get; set; }
        public virtual ICollection<LessonFitnessAssessment> LessonFitnessAssessment { get; set; }
        public virtual ICollection<PDQQuestion> PDQQuestion { get; set; }
        public virtual ICollection<PDQTask> PDQTask { get; set; }
        public virtual ICollection<Payment> Payment { get; set; }
        public virtual ICollection<PaymentAudit> PaymentAudit { get; set; }
        public virtual ICollection<PreferredLessonTime> PreferredLessonTime { get; set; }
        public virtual ICollection<QuestionnaireCoachBypass> QuestionnaireCoachBypass { get; set; }
        public virtual ICollection<QuestionnaireCoachFinish> QuestionnaireCoachFinish { get; set; }
        public virtual ICollection<QuestionnaireRequest> QuestionnaireRequestCreator { get; set; }
        public virtual ICollection<QuestionnaireRequest> QuestionnaireRequestUIDNavigation { get; set; }
        public virtual ICollection<RegisterLesson> RegisterLesson { get; set; }
        public virtual ICollection<ResetPassword> ResetPassword { get; set; }
        public virtual ICollection<UserEvent> UserEvent { get; set; }
        public virtual ICollection<UserRelationship> UserRelationshipLeader { get; set; }
        public virtual ICollection<UserRelationship> UserRelationshipUIDNavigation { get; set; }
        public virtual ICollection<UserRole> UserRole { get; set; }
        public virtual ICollection<UserRoleAuthorization> UserRoleAuthorization { get; set; }
        public virtual ICollection<UserSignature> UserSignature { get; set; }
        public virtual ICollection<VoidPayment> VoidPayment { get; set; }
        public virtual ICollection<VoidPaymentLevel> VoidPaymentLevel { get; set; }
    }
}
