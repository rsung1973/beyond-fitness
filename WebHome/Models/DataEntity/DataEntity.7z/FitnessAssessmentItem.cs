﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class FitnessAssessmentItem
    {
        public FitnessAssessmentItem()
        {
            DiagnosisAssessment = new HashSet<DiagnosisAssessment>();
            FitnessAssessmentGroup = new HashSet<FitnessAssessmentGroup>();
            FitnessDiagnosis = new HashSet<FitnessDiagnosis>();
            LearnerFitnessAssessmentResult = new HashSet<LearnerFitnessAssessmentResult>();
            LessonFitnessAssessmentReport = new HashSet<LessonFitnessAssessmentReport>();
        }

        public int ItemID { get; set; }
        public string ItemName { get; set; }
        public string Unit { get; set; }
        public int? GroupID { get; set; }
        public bool? UseSingleSide { get; set; }
        public bool? UseCustom { get; set; }

        public virtual FitnessAssessmentGroup Group { get; set; }
        public virtual ICollection<DiagnosisAssessment> DiagnosisAssessment { get; set; }
        public virtual ICollection<FitnessAssessmentGroup> FitnessAssessmentGroup { get; set; }
        public virtual ICollection<FitnessDiagnosis> FitnessDiagnosis { get; set; }
        public virtual ICollection<LearnerFitnessAssessmentResult> LearnerFitnessAssessmentResult { get; set; }
        public virtual ICollection<LessonFitnessAssessmentReport> LessonFitnessAssessmentReport { get; set; }
    }
}
