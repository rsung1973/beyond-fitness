﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class MerchandiseTransactionType
    {
        public MerchandiseTransactionType()
        {
            SubCategory = new HashSet<MerchandiseTransactionType>();
            MerchandiseTransaction = new HashSet<MerchandiseTransaction>();
        }

        public int TransactionID { get; set; }
        public string TransactionType { get; set; }
        public int? CategorySourceID { get; set; }

        public virtual MerchandiseTransactionType ParentType { get; set; }
        public virtual ICollection<MerchandiseTransactionType> SubCategory { get; set; }
        public virtual ICollection<MerchandiseTransaction> MerchandiseTransaction { get; set; }
    }
}
