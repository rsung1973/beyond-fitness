﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class GroupEvent
    {
        public int EventID { get; set; }
        public int UID { get; set; }

        public virtual UserEvent UserEvent { get; set; }
        public virtual UserProfile UserProfile { get; set; }
    }
}
