﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class PaymentOnLine
    {
        public int OrderID { get; set; }
        public int PaymentID { get; set; }
        public string mid { get; set; }
        public string tid { get; set; }
        public string oid { get; set; }
        public string pan { get; set; }
        public int? transCode { get; set; }
        public int? transMode { get; set; }
        public string transDate { get; set; }
        public string transTime { get; set; }
        public string transAmt { get; set; }
        public string approveCode { get; set; }
        public string responseCode { get; set; }
        public string responseMsg { get; set; }
        public string installmentType { get; set; }
        public int? installment { get; set; }
        public int? firstAmt { get; set; }
        public int? eachAmt { get; set; }
        public int? fee { get; set; }
        public string redeemType { get; set; }
        public int? redeemUsed { get; set; }
        public int? redeemBalance { get; set; }
        public int? creditAmt { get; set; }
        public string secureStatus { get; set; }

        public virtual PaymentTransaction Payment { get; set; }
    }
}
