﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class DocumentType
    {
        public DocumentType()
        {
            Document = new HashSet<Document>();
        }

        public int TypeID { get; set; }
        public string TypeName { get; set; }

        public virtual ICollection<Document> Document { get; set; }
    }
}
