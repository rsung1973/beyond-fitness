﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class VoidPayment
    {
        public VoidPayment()
        {
            ContractTrustTrack = new HashSet<ContractTrustTrack>();
            VoidPaymentLevel = new HashSet<VoidPaymentLevel>();
        }

        public int VoidID { get; set; }
        public int? Status { get; set; }
        public DateTime? VoidDate { get; set; }
        public int? HandlerID { get; set; }
        public string Remark { get; set; }
        public bool? Drawback { get; set; }

        public virtual UserProfile UserProfile { get; set; }
        public virtual LevelExpression LevelExpression { get; set; }
        public virtual Payment Payment { get; set; }
        public virtual ICollection<ContractTrustTrack> ContractTrustTrack { get; set; }
        public virtual ICollection<VoidPaymentLevel> VoidPaymentLevel { get; set; }
    }
}
