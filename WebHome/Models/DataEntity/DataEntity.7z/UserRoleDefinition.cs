﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class UserRoleDefinition
    {
        public UserRoleDefinition()
        {
            UserRole = new HashSet<UserRole>();
            UserRoleAuthorization = new HashSet<UserRoleAuthorization>();
        }

        public int RoleID { get; set; }
        public string SiteMenu { get; set; }
        public string Role { get; set; }

        public virtual ICollection<UserRole> UserRole { get; set; }
        public virtual ICollection<UserRoleAuthorization> UserRoleAuthorization { get; set; }
    }
}
