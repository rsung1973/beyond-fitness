﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class InvoiceNoInterval
    {
        public InvoiceNoInterval()
        {
            InvoiceNoAssignment = new HashSet<InvoiceNoAssignment>();
            VacantInvoiceNo = new HashSet<VacantInvoiceNo>();
        }

        public int IntervalID { get; set; }
        public int TrackID { get; set; }
        public int SellerID { get; set; }
        public int StartNo { get; set; }
        public int EndNo { get; set; }
        public int? GroupID { get; set; }

        public virtual InvoiceNoIntervalGroup InvoiceNoIntervalGroup { get; set; }
        public virtual InvoiceTrackCodeAssignment InvoiceTrackCodeAssignment { get; set; }
        public virtual ICollection<InvoiceNoAssignment> InvoiceNoAssignment { get; set; }
        public virtual ICollection<VacantInvoiceNo> VacantInvoiceNo { get; set; }
    }
}
