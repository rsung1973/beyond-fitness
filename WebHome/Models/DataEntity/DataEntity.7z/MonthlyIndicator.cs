﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class MonthlyIndicator
    {
        public MonthlyIndicator()
        {
            MonthlyBranchIndicator = new HashSet<MonthlyBranchIndicator>();
            MonthlyBranchRevenueIndicator = new HashSet<MonthlyBranchRevenueIndicator>();
            MonthlyCoachRevenueIndicator = new HashSet<MonthlyCoachRevenueIndicator>();
            MonthlyRevenueIndicator = new HashSet<MonthlyRevenueIndicator>();
        }

        public int PeriodID { get; set; }
        public int Year { get; set; }
        public int Month { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndExclusiveDate { get; set; }

        public virtual ICollection<MonthlyBranchIndicator> MonthlyBranchIndicator { get; set; }
        public virtual ICollection<MonthlyBranchRevenueIndicator> MonthlyBranchRevenueIndicator { get; set; }
        public virtual ICollection<MonthlyCoachRevenueIndicator> MonthlyCoachRevenueIndicator { get; set; }
        public virtual ICollection<MonthlyRevenueIndicator> MonthlyRevenueIndicator { get; set; }
    }
}
