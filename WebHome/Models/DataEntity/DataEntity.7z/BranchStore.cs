﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class BranchStore
    {
        public BranchStore()
        {
            CoachBranchMonthlyBonus = new HashSet<CoachBranchMonthlyBonus>();
            CoachMonthlySalary = new HashSet<CoachMonthlySalary>();
            CoachWorkplace = new HashSet<CoachWorkplace>();
            CourseContractExtension = new HashSet<CourseContractExtension>();
            CourseContractRevisionItem = new HashSet<CourseContractRevisionItem>();
            CourseContractView = new HashSet<CourseContractView>();
            EnterpriseCourseContract = new HashSet<EnterpriseCourseContract>();
            LessonPriceType = new HashSet<LessonPriceType>();
            LessonTime = new HashSet<LessonTime>();
            LessonTimeSettlement = new HashSet<LessonTimeSettlement>();
            MonthlyBranchIndicator = new HashSet<MonthlyBranchIndicator>();
            MonthlyBranchRevenueIndicator = new HashSet<MonthlyBranchRevenueIndicator>();
            MonthlyCoachRevenueIndicator = new HashSet<MonthlyCoachRevenueIndicator>();
            ObjectiveLessonLocation = new HashSet<ObjectiveLessonLocation>();
            PaymentTransaction = new HashSet<PaymentTransaction>();
            RegisterLesson = new HashSet<RegisterLesson>();
            TuitionAchievement = new HashSet<TuitionAchievement>();
            UserEvent = new HashSet<UserEvent>();
        }

        public int BranchID { get; set; }
        public string BranchName { get; set; }
        public int? ManagerID { get; set; }
        public int? ViceManagerID { get; set; }
        public int? Status { get; set; }
        public string EPOS_SID { get; set; }
        public string EPOS_MID { get; set; }
        public string EPOS_TID { get; set; }

        public virtual Organization Organization { get; set; }
        public virtual UserProfile Manager { get; set; }
        public virtual UserProfile ViceManager { get; set; }
        public virtual ICollection<CoachBranchMonthlyBonus> CoachBranchMonthlyBonus { get; set; }
        public virtual ICollection<CoachMonthlySalary> CoachMonthlySalary { get; set; }
        public virtual ICollection<CoachWorkplace> CoachWorkplace { get; set; }
        public virtual ICollection<CourseContractExtension> CourseContractExtension { get; set; }
        public virtual ICollection<CourseContractRevisionItem> CourseContractRevisionItem { get; set; }
        public virtual ICollection<CourseContractView> CourseContractView { get; set; }
        public virtual ICollection<EnterpriseCourseContract> EnterpriseCourseContract { get; set; }
        public virtual ICollection<LessonPriceType> LessonPriceType { get; set; }
        public virtual ICollection<LessonTime> LessonTime { get; set; }
        public virtual ICollection<LessonTimeSettlement> LessonTimeSettlement { get; set; }
        public virtual ICollection<MonthlyBranchIndicator> MonthlyBranchIndicator { get; set; }
        public virtual ICollection<MonthlyBranchRevenueIndicator> MonthlyBranchRevenueIndicator { get; set; }
        public virtual ICollection<MonthlyCoachRevenueIndicator> MonthlyCoachRevenueIndicator { get; set; }
        public virtual ICollection<ObjectiveLessonLocation> ObjectiveLessonLocation { get; set; }
        public virtual ICollection<PaymentTransaction> PaymentTransaction { get; set; }
        public virtual ICollection<RegisterLesson> RegisterLesson { get; set; }
        public virtual ICollection<TuitionAchievement> TuitionAchievement { get; set; }
        public virtual ICollection<UserEvent> UserEvent { get; set; }
    }
}
