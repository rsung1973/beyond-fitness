﻿using System;
using System.Collections.Generic;

#nullable disable

namespace WebHome.Models.DataEntity
{
    public partial class LevelExpression
    {
        public LevelExpression()
        {
            BodyDiagnosis = new HashSet<BodyDiagnosis>();
            CourseContract = new HashSet<CourseContract>();
            CourseContractLevel = new HashSet<CourseContractLevel>();
            Document = new HashSet<Document>();
            LessonComment = new HashSet<LessonComment>();
            LessonFeedBack = new HashSet<LessonFeedBack>();
            LessonPriceProperty = new HashSet<LessonPriceProperty>();
            LessonPriceSeries = new HashSet<LessonPriceSeries>();
            LessonPriceType = new HashSet<LessonPriceType>();
            MerchandiseWindow = new HashSet<MerchandiseWindow>();
            PDQQuestion = new HashSet<PDQQuestion>();
            PDQType = new HashSet<PDQType>();
            Payment = new HashSet<Payment>();
            ProfessionalLevel = new HashSet<ProfessionalLevel>();
            QuestionnaireRequest = new HashSet<QuestionnaireRequest>();
            RegisterLesson = new HashSet<RegisterLesson>();
            TrainingPlan = new HashSet<TrainingPlan>();
            UserProfile = new HashSet<UserProfile>();
            VoidPayment = new HashSet<VoidPayment>();
            VoidPaymentLevel = new HashSet<VoidPaymentLevel>();
        }

        public int LevelID { get; set; }
        public string Expression { get; set; }
        public string Description { get; set; }

        public virtual ICollection<BodyDiagnosis> BodyDiagnosis { get; set; }
        public virtual ICollection<CourseContract> CourseContract { get; set; }
        public virtual ICollection<CourseContractLevel> CourseContractLevel { get; set; }
        public virtual ICollection<Document> Document { get; set; }
        public virtual ICollection<LessonComment> LessonComment { get; set; }
        public virtual ICollection<LessonFeedBack> LessonFeedBack { get; set; }
        public virtual ICollection<LessonPriceProperty> LessonPriceProperty { get; set; }
        public virtual ICollection<LessonPriceSeries> LessonPriceSeries { get; set; }
        public virtual ICollection<LessonPriceType> LessonPriceType { get; set; }
        public virtual ICollection<MerchandiseWindow> MerchandiseWindow { get; set; }
        public virtual ICollection<PDQQuestion> PDQQuestion { get; set; }
        public virtual ICollection<PDQType> PDQType { get; set; }
        public virtual ICollection<Payment> Payment { get; set; }
        public virtual ICollection<ProfessionalLevel> ProfessionalLevel { get; set; }
        public virtual ICollection<QuestionnaireRequest> QuestionnaireRequest { get; set; }
        public virtual ICollection<RegisterLesson> RegisterLesson { get; set; }
        public virtual ICollection<TrainingPlan> TrainingPlan { get; set; }
        public virtual ICollection<UserProfile> UserProfile { get; set; }
        public virtual ICollection<VoidPayment> VoidPayment { get; set; }
        public virtual ICollection<VoidPaymentLevel> VoidPaymentLevel { get; set; }
    }
}
